package Junit;

import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import singleton.Magazin;

public class TestMagazin extends TestCase{
	

	private Magazin singleton;
	

	@Before
	public void initialize(){
		try{
			singleton=Magazin.getSingleton();
		}
		catch(Exception e){
			
		}
	}
	
	@Before
	public void setUp() throws Exception {
		System.out.println("setUp");
		Magazin.getSingleton().setDenumire("Catex");
		Magazin.getSingleton().setCod("134");
		Magazin.getSingleton().setAdresa("Constanta");
		
	}


	@Test
	public void test_instanta_unica(){
		Magazin singleton2=null;
		try{
			singleton2=Magazin.getSingleton();
		}catch(Exception e){
			assertNotEquals(singleton2, null);
			assertEquals(singleton2.getAdresa(),"Bucuresti");
			assertEquals(singleton2.getCod(),"123");
			assertEquals(singleton2.getDenumire(),"Cartex");
			
		}
	}
	@Test
	public void test_verificare_cod() {
		try{
			Magazin.getSingleton().setCod("3464");
			assertEquals("3464",Magazin.getSingleton().getCod());
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	@Test
	public void test_denumire_corect(){
		try{
			Magazin.getSingleton().setDenumire("Catex");
			assertEquals("Catex",Magazin.getSingleton().getDenumire());
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void test_verificare_cod_incorect(){
		try{
			Magazin.getSingleton().setCod("magazin");
			assertTrue(Magazin.getSingleton().verifica_cod());
			fail("Codul este incorect!");
		}
		catch(Exception e){
			
		}
	}
	@Test
	public void test_denumire_incorect(){
		try{
			Magazin.getSingleton().setDenumire("magazin");
			assertEquals("magazin",Magazin.getSingleton().getDenumire());
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void test_adresa_corect(){
		try{
			Magazin.getSingleton().setAdresa("Bucuresti");
			assertEquals("Bucuresti",Magazin.getSingleton().getAdresa());
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void test_adresa_incorect(){
		try{
			Magazin.getSingleton().setAdresa("Suceava");
			assertEquals("Suceava",Magazin.getSingleton().getAdresa());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@After
	public void distruge(){
		singleton=null;
	}
	

}
