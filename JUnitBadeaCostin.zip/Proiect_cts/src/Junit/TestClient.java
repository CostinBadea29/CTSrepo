package Junit;

import static org.junit.Assert.*;
import interfete.ModalitatePlata;
import junit.framework.TestCase;
import Strategy.Client;
import Strategy.PlataCard;
import Strategy.PlataCash;

import org.junit.Test;

public class TestClient extends TestCase{
	
	public TestClient(String nume){
		super(nume);
	}

	@Test
	public void testNumeClientCorect(){
		Client client=new Client();
		try{
			client.setNume("Ionut");
			assertEquals("Ionut",client.getNume());
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void testModalitatePlataCard(){
		Client client=new Client();
		ModalitatePlata mod=new PlataCard();
		try{
			client.setModalitate(mod);
			assertEquals(mod,client.getModalitate());
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void testModalitateCash(){
		Client client=new Client();
		ModalitatePlata mod=new PlataCash();
		try{
			client.setModalitate(mod);
			assertEquals(mod,client.getModalitate());
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
