package Junit;

import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.Test;

import Builder.Cola;

public class TestCola extends TestCase{
	
	Cola cola=new Cola();

	@Test
	public void testPretCola() {
		assertEquals(30.0f,cola.pret());
	}
	@Test
	public void testDenumire(){
		assertEquals("Coca-Cola",cola.denumire());
	}

}
