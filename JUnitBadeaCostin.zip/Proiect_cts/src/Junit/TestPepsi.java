package Junit;

import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.Test;

import Builder.Pepsi;

public class TestPepsi extends TestCase{

	Pepsi pepsi=new Pepsi();
	
	@Test
	public void testPretPepsi() {
		assertEquals(30.0f,pepsi.pret());
	}
	@Test
	public void testDenumire(){
		assertEquals("Pepsi",pepsi.denumire());
	}

}
