package Junit;

import static org.junit.Assert.*;

import java.util.List;
import java.util.ArrayList;

import junit.framework.TestCase;
import Adapter.MateriePrima;

import org.junit.Test;

public class TestMateriePrima extends TestCase{

	@Test
	public void test_lista_not_null() {
		MateriePrima mp=new MateriePrima("zahar");
		List<String> lista_not_null=mp.lista_mp(6);
		assertNotNull(lista_not_null);
	}
	@Test
	public void test_lista_null(){
		MateriePrima mp=new MateriePrima();
		List<String> lista_null=mp.lista_mp(0);
		assertNull(lista_null);
	}
	@Test
	public void testNumeMaterie(){
		MateriePrima mp=new MateriePrima();
		mp.setNume("sare");
		assertEquals("sare",mp.getNume());
	}
	@Test
	public void testNumeIncorectMaterie(){
		try{
		MateriePrima mp=new MateriePrima();
		mp.setNume("");
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
