package Junit;

import junit.framework.TestCase;

import org.junit.Test;

import composite.Angajat;

public class TestAngajat extends TestCase{
	
	Angajat angajat=new Angajat();
	public TestAngajat(String nume){
		super(nume);
	}

	
	@Test
	public void testNumeAngajat() {
		
		angajat.setNume("Andrei");
		assertEquals("Andrei",angajat.getNume());
	}
	
	@Test
	public void testPozitieAngajat(){
		try{
			angajat.setPozitie("entry level");
			assertEquals("entry level",angajat.getPozitie());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	@Test
	public void testSalariutotal() {
		Angajat ang=new Angajat("Mihai","manager",2300,"0732333443");
		int rezultat=ang.totalSalariu(2300);
		assertEquals(27600,rezultat);
	}
	@Test
	public boolean test_salariu_par(){
		Angajat ang=new Angajat("Marius","manager",1000,"07356663343");
		int rezultat=ang.totalSalariu(1000);
		if(rezultat%2==0)
			return true;
		else
			return false;
	}
	@Test
	public boolean test_salariu_impar(){
		int rezultat=angajat.totalSalariu(1000);
		if(rezultat%2!=0)
			return true;
		else
			return false;
	}
	@Test
	public void testNull(){
		angajat.setNume(null);
		assertNull("Numele angajatului:null",this.angajat.getNume());

	}
	@Test
	public void testNotNull(){
		assertNotNull(this.angajat);
	}
	}

