package Junit;

import static org.junit.Assert.*;

import java.util.List;

import junit.framework.TestCase;
import interfete.Produs;
import Adapter.MateriePrima;
import Builder.Meniu;
import Builder.MeniuBuilder;
import Builder.Pepsi;

import org.junit.Test;

public class TestMeniu extends TestCase{

	
	
	@Test
	public void test_calculeazaValoareMeniu() {
		MeniuBuilder meniub = new MeniuBuilder();
		Meniu meniu=meniub.creazaMeniu();
		float rez_meniu=meniu.calculeazaValoareMeniu();
		assertEquals(67,0,rez_meniu);
	}
	@Test
	public void test_calculeazaValoareMeniuVegetarian(){
		MeniuBuilder meniub=new MeniuBuilder();
		Meniu meniuv=meniub.creazaMeniuVegetarian();
		float rez_meniu_veg=meniuv.calculeazaValoareMeniu();
		assertEquals(75,0,rez_meniu_veg);
	}
	@Test
	public void test_lista_not_null() {
		Meniu meniu=new Meniu();
		List<String> lista_not_null=meniu.lista_meniu(6);
		assertNotNull(lista_not_null);
	}
	@Test
	public void test_lista_null(){
		Meniu meniu=new Meniu();
		List<String> lista_null=meniu.lista_meniu(0);
		assertNull(lista_null);
	}
	

}
