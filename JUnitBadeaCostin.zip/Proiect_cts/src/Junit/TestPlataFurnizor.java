package Junit;

import static org.junit.Assert.*;
import junit.framework.TestResult;

import org.junit.Test;

import chainofresponsability.MateriePrimaChain;
import chainofresponsability.PlataFurnizor;
import chainofresponsability.Tasks;

public class TestPlataFurnizor implements junit.framework.Test {

	Tasks pf=new PlataFurnizor();

	@Test
	public void testVerifica() {
		int num=60;
		int plata=num*20;
		assertEquals(1200,plata);
	}
	
	@Test
	public void testVerificaPar(){
		 pf.verifica(40);
		
}

	public int countTestCases() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void run(TestResult arg0) {
		// TODO Auto-generated method stub
		
	}
}

