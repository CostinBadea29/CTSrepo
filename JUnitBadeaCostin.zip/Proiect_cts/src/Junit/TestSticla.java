package Junit;

import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.Test;

import Builder.Sticla;

public class TestSticla extends TestCase{

	Sticla sticla=new Sticla();
	
	@Test
	public void testAmbalare() {
		assertEquals("Produsul este imbuteliat",sticla.ambalare());
	}
	@Test
	public void testAmbalareNotNull(){
		try{
			assertNotNull(sticla.ambalare());
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
