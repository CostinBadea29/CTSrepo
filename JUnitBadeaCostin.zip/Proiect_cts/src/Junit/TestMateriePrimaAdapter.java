package Junit;

import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.Test;

import Adapter.MateriePrima;
import Adapter.MateriePrimaAdapter;

public class TestMateriePrimaAdapter extends TestCase{

	MateriePrimaAdapter mpa=new MateriePrimaAdapter();
	MateriePrima mp=new MateriePrima();
	
	@Test
	public void testMateriePrimaAdapter() {
		mp.setNume("Materie Prima");
		mpa.setMp(mp);
		assertEquals(mp,mpa.getMp());
	}

}
