package Junit;

import junit.framework.TestSuite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
@RunWith(Suite.class)
@Suite.SuiteClasses({TestAngajat.class,TestClient.class,
	TestCola.class,TestLogoMagazin.class,TestMagazin.class,
	TestMateriePrima.class,TestMateriePrimaAdapter.class,
	TestMeniu.class,TestPepsi.class,TestPlataFurnizor.class,
	TestSticla.class})
public class JUnitTestSuite {

	public static TestSuite testSuiteMethod(){
		TestSuite t=new TestSuite();
		t.addTestSuite(TestAngajat.class);
		t.addTestSuite(TestClient.class);
		t.addTestSuite(TestCola.class);
		t.addTestSuite(TestMagazin.class);
		t.addTestSuite(TestMateriePrima.class);
		t.addTestSuite(TestMateriePrimaAdapter.class);
		t.addTestSuite(TestMeniu.class);
		t.addTestSuite(TestPepsi.class);
		t.addTest(new TestPlataFurnizor());
		t.addTestSuite(TestSticla.class);
		t.addTest(new TestLogoMagazin());
		
		return t;
	}

}
