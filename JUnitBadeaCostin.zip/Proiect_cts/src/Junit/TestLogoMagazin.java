package Junit;

import static org.junit.Assert.*;
import junit.framework.TestResult;

import org.junit.Test;

import proxy.LogoMagazin;

public class TestLogoMagazin implements junit.framework.Test {

	LogoMagazin logo=new LogoMagazin();
	
	@Test
	public void testDenumireLogo() {
		logo.setDenumire("logo.jpg");
		assertEquals("logo.jpg",logo.getDenumire());
	}
	
	@Test
	public void testDimensiuneLogo(){
		logo.setDimensiune(1300);
		assertEquals(1300,logo.getDimensiune());
	}

	public int countTestCases() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void run(TestResult arg0) {
		// TODO Auto-generated method stub
		
	}

}
